﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees.Entities
{
    internal class Salaried : Employee
    {
        private double salary;

        public double salaried { get { return salary; } }

        /// <summary>
        /// User-defined constructor 
        /// </summary>
        /// <param name="id">Employee ID</param>
        /// <param name="name">Name of Emplooyes</param>
        /// <param name="address">Employee's address</param>
        /// <param name="salary">Employee's salary</param>



        public Salaried(string id, string name, string address, double salary)
        {
            this.id = id;
            this.name = name;
            this.address = address;
            this.salary = salary;

        }
        public override double CalcWeeklyPay()
        {
            return this.salary;
        }

    }
}
